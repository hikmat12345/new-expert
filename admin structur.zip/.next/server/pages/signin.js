"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/signin";
exports.ids = ["pages/signin"];
exports.modules = {

/***/ "./src/pages/signin.tsx":
/*!******************************!*\
  !*** ./src/pages/signin.tsx ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _styles_Container_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/styles/Container.styled */ \"./src/styles/Container.styled.tsx\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\nfunction Signin() {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_styles_Container_styled__WEBPACK_IMPORTED_MODULE_1__.LoginContainer, {\n        children: \"Signin\"\n    }, void 0, false, {\n        fileName: \"D:\\\\Selt data\\\\Code\\\\Git Configured Code\\\\new-expert\\\\src\\\\pages\\\\signin.tsx\",\n        lineNumber: 8,\n        columnNumber: 5\n    }, this);\n}\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Signin);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvcGFnZXMvc2lnbmluLnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQTJEO0FBQzVCO0FBRy9CLFNBQVNFLFNBQVM7SUFFaEIscUJBQ0UsOERBQUNGLG9FQUFjQTtrQkFBQzs7Ozs7O0FBSXBCO0FBRUEsaUVBQWVFLE1BQU1BLEVBQUEiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9uZXctZXhwZXJ0Ly4vc3JjL3BhZ2VzL3NpZ25pbi50c3g/ZTY0MyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBMb2dpbkNvbnRhaW5lciB9IGZyb20gJ0Avc3R5bGVzL0NvbnRhaW5lci5zdHlsZWQnO1xyXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7IFxyXG5cclxuIFxyXG5mdW5jdGlvbiBTaWduaW4oKSB7XHJcbiAgICBcclxuICByZXR1cm4gKFxyXG4gICAgPExvZ2luQ29udGFpbmVyPlxyXG4gICAgICAgU2lnbmluXHJcbiAgICA8L0xvZ2luQ29udGFpbmVyPlxyXG4gIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgU2lnbmluXHJcbiJdLCJuYW1lcyI6WyJMb2dpbkNvbnRhaW5lciIsIlJlYWN0IiwiU2lnbmluIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./src/pages/signin.tsx\n");

/***/ }),

/***/ "./src/styles/Container.styled.tsx":
/*!*****************************************!*\
  !*** ./src/styles/Container.styled.tsx ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"Container\": () => (/* binding */ Container),\n/* harmony export */   \"LoginContainer\": () => (/* binding */ LoginContainer)\n/* harmony export */ });\n/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ \"styled-components\");\n/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);\n\nconst Container = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`\r\n  width: 1226px;\r\n  max-width: 100%;\r\n  padding: 0 20px;\r\n  padding: 0 8.5px 0 0;\r\n  opacity: 0.5;\r\n  margin: 0 auto;\r\n`;\nconst LoginContainer = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`\r\n padding: 20 70px;\r\n background-color: #f1f6fa;\r\n`;\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvc3R5bGVzL0NvbnRhaW5lci5zdHlsZWQudHN4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFBc0M7QUFFL0IsTUFBTUMsWUFBWUQsOERBQVUsQ0FBQzs7Ozs7OztBQU9wQyxDQUFDO0FBQ00sTUFBTUcsaUJBQWlCSCw4REFBVSxDQUFDOzs7QUFHekMsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL25ldy1leHBlcnQvLi9zcmMvc3R5bGVzL0NvbnRhaW5lci5zdHlsZWQudHN4P2RlNDciXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHN0eWxlZCBmcm9tICdzdHlsZWQtY29tcG9uZW50cydcclxuXHJcbmV4cG9ydCBjb25zdCBDb250YWluZXIgPSBzdHlsZWQuZGl2YFxyXG4gIHdpZHRoOiAxMjI2cHg7XHJcbiAgbWF4LXdpZHRoOiAxMDAlO1xyXG4gIHBhZGRpbmc6IDAgMjBweDtcclxuICBwYWRkaW5nOiAwIDguNXB4IDAgMDtcclxuICBvcGFjaXR5OiAwLjU7XHJcbiAgbWFyZ2luOiAwIGF1dG87XHJcbmBcclxuZXhwb3J0IGNvbnN0IExvZ2luQ29udGFpbmVyID0gc3R5bGVkLmRpdmBcclxuIHBhZGRpbmc6IDIwIDcwcHg7XHJcbiBiYWNrZ3JvdW5kLWNvbG9yOiAjZjFmNmZhO1xyXG5gIl0sIm5hbWVzIjpbInN0eWxlZCIsIkNvbnRhaW5lciIsImRpdiIsIkxvZ2luQ29udGFpbmVyIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./src/styles/Container.styled.tsx\n");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "styled-components":
/*!************************************!*\
  !*** external "styled-components" ***!
  \************************************/
/***/ ((module) => {

module.exports = require("styled-components");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./src/pages/signin.tsx"));
module.exports = __webpack_exports__;

})();