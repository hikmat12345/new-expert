"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./src/Components/Header/Header.tsx":
/*!******************************************!*\
  !*** ./src/Components/Header/Header.tsx ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Header)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _styles_Header_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/styles/Header.styled */ \"./src/styles/Header.styled.tsx\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\nfunction Header(props) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_styles_Header_styled__WEBPACK_IMPORTED_MODULE_1__.StyledHeader, {\n        children: \"Header\"\n    }, void 0, false, {\n        fileName: \"D:\\\\Selt data\\\\Code\\\\Git Configured Code\\\\new-expert\\\\src\\\\Components\\\\Header\\\\Header.tsx\",\n        lineNumber: 6,\n        columnNumber: 5\n    }, this);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvQ29tcG9uZW50cy9IZWFkZXIvSGVhZGVyLnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQXFEO0FBQzVCO0FBRVYsU0FBU0UsT0FBT0MsS0FBUyxFQUFFO0lBQ3hDLHFCQUNFLDhEQUFDSCwrREFBWUE7a0JBQUM7Ozs7OztBQUlsQixDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vbmV3LWV4cGVydC8uL3NyYy9Db21wb25lbnRzL0hlYWRlci9IZWFkZXIudHN4Pzk1MzciXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgU3R5bGVkSGVhZGVyIH0gZnJvbSAnQC9zdHlsZXMvSGVhZGVyLnN0eWxlZCdcclxuaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0J1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gSGVhZGVyKHByb3BzOmFueSkge1xyXG4gIHJldHVybiAoXHJcbiAgICA8U3R5bGVkSGVhZGVyPlxyXG4gICAgICBIZWFkZXJcclxuICAgIDwvU3R5bGVkSGVhZGVyPlxyXG4gIClcclxufVxyXG4iXSwibmFtZXMiOlsiU3R5bGVkSGVhZGVyIiwiUmVhY3QiLCJIZWFkZXIiLCJwcm9wcyJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/Components/Header/Header.tsx\n");

/***/ }),

/***/ "./src/Components/Layout/Layout.tsx":
/*!******************************************!*\
  !*** ./src/Components/Layout/Layout.tsx ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"Layout\": () => (/* binding */ Layout)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _Header_Header__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../Header/Header */ \"./src/Components/Header/Header.tsx\");\n/* harmony import */ var _styles_Global__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../styles/Global */ \"./src/styles/Global.tsx\");\n// components/Layout.js\n\n\n\nconst Layout = ({ children  })=>{\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_styles_Global__WEBPACK_IMPORTED_MODULE_2__[\"default\"], {}, void 0, false, {\n                fileName: \"D:\\\\Selt data\\\\Code\\\\Git Configured Code\\\\new-expert\\\\src\\\\Components\\\\Layout\\\\Layout.tsx\",\n                lineNumber: 10,\n                columnNumber: 12\n            }, undefined),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Header_Header__WEBPACK_IMPORTED_MODULE_1__[\"default\"], {}, void 0, false, {\n                fileName: \"D:\\\\Selt data\\\\Code\\\\Git Configured Code\\\\new-expert\\\\src\\\\Components\\\\Layout\\\\Layout.tsx\",\n                lineNumber: 11,\n                columnNumber: 13\n            }, undefined),\n            children\n        ]\n    }, void 0, true, {\n        fileName: \"D:\\\\Selt data\\\\Code\\\\Git Configured Code\\\\new-expert\\\\src\\\\Components\\\\Layout\\\\Layout.tsx\",\n        lineNumber: 9,\n        columnNumber: 8\n    }, undefined);\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvQ29tcG9uZW50cy9MYXlvdXQvTGF5b3V0LnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBLHVCQUF1Qjs7QUFDZ0I7QUFDUTtBQUV4QyxNQUFNRSxTQUFTLENBQ3JCLEVBQUNDLFNBQVEsRUFBZ0IsR0FDdkI7SUFDQSxxQkFDSSw4REFBQ0M7OzBCQUNHLDhEQUFDSCxzREFBWUE7Ozs7OzBCQUNaLDhEQUFDRCxzREFBTUE7Ozs7O1lBQ0xHOzs7Ozs7O0FBR2QsRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovL25ldy1leHBlcnQvLi9zcmMvQ29tcG9uZW50cy9MYXlvdXQvTGF5b3V0LnRzeD85NGIyIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIGNvbXBvbmVudHMvTGF5b3V0LmpzXHJcbiBpbXBvcnQgSGVhZGVyIGZyb20gJy4uL0hlYWRlci9IZWFkZXInO1xyXG5pbXBvcnQgR2xvYmFsU3R5bGVzIGZyb20gJy4uLy4uL3N0eWxlcy9HbG9iYWwnO1xyXG5cclxuZXhwb3J0IGNvbnN0IExheW91dCA9IChcclxuIHtjaGlsZHJlbn06e2NoaWxkcmVuOmFueX1cclxuKT0+e1xyXG4gICByZXR1cm4gKFxyXG4gICAgICAgPGRpdj5cclxuICAgICAgICAgICA8R2xvYmFsU3R5bGVzIC8+XHJcbiAgICAgICAgICAgIDxIZWFkZXIgLz5cclxuICAgICAgICAgICAgIHtjaGlsZHJlbn1cclxuICAgICAgIDwvZGl2PlxyXG4gICAgKTsgXHJcbn0iXSwibmFtZXMiOlsiSGVhZGVyIiwiR2xvYmFsU3R5bGVzIiwiTGF5b3V0IiwiY2hpbGRyZW4iLCJkaXYiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/Components/Layout/Layout.tsx\n");

/***/ }),

/***/ "./src/pages/_app.tsx":
/*!****************************!*\
  !*** ./src/pages/_app.tsx ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ App)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _Components_Layout_Layout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/Components/Layout/Layout */ \"./src/Components/Layout/Layout.tsx\");\n/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/utils/utils */ \"./src/utils/utils.ts\");\n/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! styled-components */ \"styled-components\");\n/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_3__);\n\n\n\n\nfunction App({ Component , pageProps  }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(styled_components__WEBPACK_IMPORTED_MODULE_3__.ThemeProvider, {\n        theme: _utils_utils__WEBPACK_IMPORTED_MODULE_2__.theme,\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Components_Layout_Layout__WEBPACK_IMPORTED_MODULE_1__.Layout, {\n            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n                ...pageProps\n            }, void 0, false, {\n                fileName: \"D:\\\\Selt data\\\\Code\\\\Git Configured Code\\\\new-expert\\\\src\\\\pages\\\\_app.tsx\",\n                lineNumber: 11,\n                columnNumber: 7\n            }, this)\n        }, void 0, false, {\n            fileName: \"D:\\\\Selt data\\\\Code\\\\Git Configured Code\\\\new-expert\\\\src\\\\pages\\\\_app.tsx\",\n            lineNumber: 10,\n            columnNumber: 5\n        }, this)\n    }, void 0, false, {\n        fileName: \"D:\\\\Selt data\\\\Code\\\\Git Configured Code\\\\new-expert\\\\src\\\\pages\\\\_app.tsx\",\n        lineNumber: 9,\n        columnNumber: 3\n    }, this);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvcGFnZXMvX2FwcC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7QUFDbUQ7QUFDZDtBQUVZO0FBQ2xDLFNBQVNHLElBQUksRUFBRUMsVUFBUyxFQUFFQyxVQUFTLEVBQVksRUFBRTtJQUM5RCxxQkFFQSw4REFBQ0gsNERBQWFBO1FBQUNELE9BQU9BLCtDQUFLQTtrQkFDekIsNEVBQUNELDZEQUFNQTtzQkFDTCw0RUFBQ0k7Z0JBQVcsR0FBR0MsU0FBUzs7Ozs7Ozs7Ozs7Ozs7OztBQUk5QixDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vbmV3LWV4cGVydC8uL3NyYy9wYWdlcy9fYXBwLnRzeD9mOWQ2Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBIZWFkZXIgZnJvbSAnQC9Db21wb25lbnRzL0hlYWRlci9IZWFkZXInXG5pbXBvcnQgeyBMYXlvdXQgfSBmcm9tICdAL0NvbXBvbmVudHMvTGF5b3V0L0xheW91dCdcbmltcG9ydCB7IHRoZW1lIH0gZnJvbSAnQC91dGlscy91dGlscydcbmltcG9ydCB0eXBlIHsgQXBwUHJvcHMgfSBmcm9tICduZXh0L2FwcCdcbmltcG9ydCB7IFRoZW1lUHJvdmlkZXIgfSBmcm9tICdzdHlsZWQtY29tcG9uZW50cydcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEFwcCh7IENvbXBvbmVudCwgcGFnZVByb3BzIH06IEFwcFByb3BzKSB7XG4gIHJldHVybiAoXG5cbiAgPFRoZW1lUHJvdmlkZXIgdGhlbWU9e3RoZW1lfT5cbiAgICA8TGF5b3V0PlxuICAgICAgPENvbXBvbmVudCB7Li4ucGFnZVByb3BzfSAvPlxuICAgIDwvTGF5b3V0PlxuICA8L1RoZW1lUHJvdmlkZXI+XG4gIClcbn1cbiJdLCJuYW1lcyI6WyJMYXlvdXQiLCJ0aGVtZSIsIlRoZW1lUHJvdmlkZXIiLCJBcHAiLCJDb21wb25lbnQiLCJwYWdlUHJvcHMiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/pages/_app.tsx\n");

/***/ }),

/***/ "./src/styles/Global.tsx":
/*!*******************************!*\
  !*** ./src/styles/Global.tsx ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ \"styled-components\");\n/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);\n\nconst GlobalStyles = styled_components__WEBPACK_IMPORTED_MODULE_0__.createGlobalStyle`\r\n  @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap');\r\n  * {\r\n    box-sizing: border-box;\r\n  }\r\n  body {\r\n    background: ${({ theme  })=>theme.colors.body};\r\n    color: hsl(192, 100%, 9%);\r\n    font-family: 'Poppins', sans-serif;\r\n    font-size: 1.15em;\r\n    margin: 0;\r\n  }\r\n  p {\r\n    opacity: 0.6;\r\n    line-height: 1.5;\r\n  }\r\n  img {\r\n    max-width: 100%;\r\n}\r\n`;\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (GlobalStyles);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvc3R5bGVzL0dsb2JhbC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQXFEO0FBRXJELE1BQU1DLGVBQWVELGdFQUFpQixDQUFDOzs7Ozs7Z0JBTXZCLEVBQUUsQ0FBQyxFQUFFRSxNQUFLLEVBQWUsR0FBS0EsTUFBTUMsTUFBTSxDQUFDQyxJQUFJLENBQUM7Ozs7Ozs7Ozs7Ozs7QUFhaEUsQ0FBQztBQUVELGlFQUFlSCxZQUFZQSxFQUFBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vbmV3LWV4cGVydC8uL3NyYy9zdHlsZXMvR2xvYmFsLnRzeD9kNzNmIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNyZWF0ZUdsb2JhbFN0eWxlIH0gZnJvbSAnc3R5bGVkLWNvbXBvbmVudHMnXHJcblxyXG5jb25zdCBHbG9iYWxTdHlsZXMgPSBjcmVhdGVHbG9iYWxTdHlsZWBcclxuICBAaW1wb3J0IHVybCgnaHR0cHM6Ly9mb250cy5nb29nbGVhcGlzLmNvbS9jc3MyP2ZhbWlseT1Qb3BwaW5zOndnaHRAMzAwOzQwMDs2MDA7NzAwJmRpc3BsYXk9c3dhcCcpO1xyXG4gICoge1xyXG4gICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcclxuICB9XHJcbiAgYm9keSB7XHJcbiAgICBiYWNrZ3JvdW5kOiAkeyh7IHRoZW1lIH06e3RoZW1lOiBhbnl9KSA9PiB0aGVtZS5jb2xvcnMuYm9keX07XHJcbiAgICBjb2xvcjogaHNsKDE5MiwgMTAwJSwgOSUpO1xyXG4gICAgZm9udC1mYW1pbHk6ICdQb3BwaW5zJywgc2Fucy1zZXJpZjtcclxuICAgIGZvbnQtc2l6ZTogMS4xNWVtO1xyXG4gICAgbWFyZ2luOiAwO1xyXG4gIH1cclxuICBwIHtcclxuICAgIG9wYWNpdHk6IDAuNjtcclxuICAgIGxpbmUtaGVpZ2h0OiAxLjU7XHJcbiAgfVxyXG4gIGltZyB7XHJcbiAgICBtYXgtd2lkdGg6IDEwMCU7XHJcbn1cclxuYFxyXG5cclxuZXhwb3J0IGRlZmF1bHQgR2xvYmFsU3R5bGVzIl0sIm5hbWVzIjpbImNyZWF0ZUdsb2JhbFN0eWxlIiwiR2xvYmFsU3R5bGVzIiwidGhlbWUiLCJjb2xvcnMiLCJib2R5Il0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./src/styles/Global.tsx\n");

/***/ }),

/***/ "./src/styles/Header.styled.tsx":
/*!**************************************!*\
  !*** ./src/styles/Header.styled.tsx ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"Image\": () => (/* binding */ Image),\n/* harmony export */   \"Logo\": () => (/* binding */ Logo),\n/* harmony export */   \"Nav\": () => (/* binding */ Nav),\n/* harmony export */   \"StyledHeader\": () => (/* binding */ StyledHeader)\n/* harmony export */ });\n/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ \"styled-components\");\n/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);\n\nconst StyledHeader = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().header)`\r\n  background-color: ${({ theme  })=>theme.colors.header || \"#fff\"};\r\n  height: 65px;\r\n  padding: 0 0 7px;\r\n  box-shadow: 0 1px 4px 0 rgba(0, 0, 0, 0.16);\r\n `;\nconst Nav = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().nav)`\r\n  display: flex;\r\n  align-items: center;\r\n  justify-content: space-between;\r\n  margin-bottom: 40px;\r\n  @media (max-width: ${({ theme  })=>theme.mobile}) {\r\n    flex-direction: column;\r\n  }\r\n`;\nconst Logo = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().img)`\r\n  @media (max-width: ${({ theme  })=>theme.mobile}) {\r\n    margin-bottom: 40px;\r\n  }\r\n`;\nconst Image = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().img)`\r\n  width: 375px;\r\n  margin-left: 40px;\r\n  @media (max-width: ${({ theme  })=>theme.mobile}) {\r\n    margin: 40px 0 30px;\r\n  }\r\n`;\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvc3R5bGVzL0hlYWRlci5zdHlsZWQudHN4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFzQztBQUUvQixNQUFNQyxlQUFlRCxpRUFBYSxDQUFDO29CQUN0QixFQUFFLENBQUMsRUFBRUcsTUFBSyxFQUFNLEdBQUtBLE1BQU1DLE1BQU0sQ0FBQ0YsTUFBTSxJQUFJLE9BQU87Ozs7Q0FJdEUsQ0FBQztBQUVLLE1BQU1HLE1BQU1MLDhEQUFVLENBQUM7Ozs7O3FCQUtULEVBQUUsQ0FBQyxFQUFFRyxNQUFLLEVBQUUsR0FBS0EsTUFBTUksTUFBTSxDQUFDOzs7QUFHbkQsQ0FBQztBQUVNLE1BQU1DLE9BQU9SLDhEQUFVLENBQUM7cUJBQ1YsRUFBRSxDQUFDLEVBQUVHLE1BQUssRUFBRSxHQUFLQSxNQUFNSSxNQUFNLENBQUM7OztBQUduRCxDQUFDO0FBRU0sTUFBTUcsUUFBUVYsOERBQVUsQ0FBQzs7O3FCQUdYLEVBQUUsQ0FBQyxFQUFFRyxNQUFLLEVBQUUsR0FBS0EsTUFBTUksTUFBTSxDQUFDOzs7QUFHbkQsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL25ldy1leHBlcnQvLi9zcmMvc3R5bGVzL0hlYWRlci5zdHlsZWQudHN4P2YwZGQiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHN0eWxlZCBmcm9tICdzdHlsZWQtY29tcG9uZW50cydcclxuXHJcbmV4cG9ydCBjb25zdCBTdHlsZWRIZWFkZXIgPSBzdHlsZWQuaGVhZGVyYFxyXG4gIGJhY2tncm91bmQtY29sb3I6ICR7KHsgdGhlbWUgfTphbnkpID0+IHRoZW1lLmNvbG9ycy5oZWFkZXIgfHwgXCIjZmZmXCJ9O1xyXG4gIGhlaWdodDogNjVweDtcclxuICBwYWRkaW5nOiAwIDAgN3B4O1xyXG4gIGJveC1zaGFkb3c6IDAgMXB4IDRweCAwIHJnYmEoMCwgMCwgMCwgMC4xNik7XHJcbiBgXHJcblxyXG5leHBvcnQgY29uc3QgTmF2ID0gc3R5bGVkLm5hdmBcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gIG1hcmdpbi1ib3R0b206IDQwcHg7XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUubW9iaWxlfSkge1xyXG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICB9XHJcbmBcclxuXHJcbmV4cG9ydCBjb25zdCBMb2dvID0gc3R5bGVkLmltZ2BcclxuICBAbWVkaWEgKG1heC13aWR0aDogJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5tb2JpbGV9KSB7XHJcbiAgICBtYXJnaW4tYm90dG9tOiA0MHB4O1xyXG4gIH1cclxuYFxyXG5cclxuZXhwb3J0IGNvbnN0IEltYWdlID0gc3R5bGVkLmltZ2BcclxuICB3aWR0aDogMzc1cHg7XHJcbiAgbWFyZ2luLWxlZnQ6IDQwcHg7XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUubW9iaWxlfSkge1xyXG4gICAgbWFyZ2luOiA0MHB4IDAgMzBweDtcclxuICB9XHJcbmAiXSwibmFtZXMiOlsic3R5bGVkIiwiU3R5bGVkSGVhZGVyIiwiaGVhZGVyIiwidGhlbWUiLCJjb2xvcnMiLCJOYXYiLCJuYXYiLCJtb2JpbGUiLCJMb2dvIiwiaW1nIiwiSW1hZ2UiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/styles/Header.styled.tsx\n");

/***/ }),

/***/ "./src/utils/utils.ts":
/*!****************************!*\
  !*** ./src/utils/utils.ts ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"theme\": () => (/* binding */ theme)\n/* harmony export */ });\nconst theme = {\n    colors: {\n        black: \"#000\",\n        grayBlack: \"grey\",\n        white: \"#fff\",\n        redColor: \"red\"\n    }\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvdXRpbHMvdXRpbHMudHMuanMiLCJtYXBwaW5ncyI6Ijs7OztBQUNPLE1BQU1BLFFBQVE7SUFDakJDLFFBQU87UUFDSEMsT0FBTztRQUNQQyxXQUFVO1FBQ1ZDLE9BQU07UUFDTkMsVUFBUztJQUNiO0FBQ0osRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovL25ldy1leHBlcnQvLi9zcmMvdXRpbHMvdXRpbHMudHM/YWFiZSJdLCJzb3VyY2VzQ29udGVudCI6WyJcclxuZXhwb3J0IGNvbnN0IHRoZW1lID0ge1xyXG4gICAgY29sb3JzOntcclxuICAgICAgICBibGFjazogXCIjMDAwXCIsXHJcbiAgICAgICAgZ3JheUJsYWNrOlwiZ3JleVwiLCBcclxuICAgICAgICB3aGl0ZTpcIiNmZmZcIixcclxuICAgICAgICByZWRDb2xvcjpcInJlZFwiXHJcbiAgICB9XHJcbn0iXSwibmFtZXMiOlsidGhlbWUiLCJjb2xvcnMiLCJibGFjayIsImdyYXlCbGFjayIsIndoaXRlIiwicmVkQ29sb3IiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/utils/utils.ts\n");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "styled-components":
/*!************************************!*\
  !*** external "styled-components" ***!
  \************************************/
/***/ ((module) => {

module.exports = require("styled-components");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./src/pages/_app.tsx"));
module.exports = __webpack_exports__;

})();