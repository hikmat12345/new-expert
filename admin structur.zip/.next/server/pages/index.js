"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/index";
exports.ids = ["pages/index"];
exports.modules = {

/***/ "./src/Tags/Container/Container.tsx":
/*!******************************************!*\
  !*** ./src/Tags/Container/Container.tsx ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! styled-components */ \"styled-components\");\n/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\nconst Buttons = (styled_components__WEBPACK_IMPORTED_MODULE_2___default().button)`\r\nfont-family:\"poppins\"\r\n  `;\nfunction Container({ children  }) {\n    const Wrappertag = (styled_components__WEBPACK_IMPORTED_MODULE_2___default().div)`\r\n    font-family:'poppins';\r\n   `;\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Wrappertag, {\n        children: children\n    }, void 0, false, {\n        fileName: \"D:\\\\Selt data\\\\Code\\\\Git Configured Code\\\\new-expert\\\\src\\\\Tags\\\\Container\\\\Container.tsx\",\n        lineNumber: 12,\n        columnNumber: 5\n    }, this);\n}\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Container);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvVGFncy9Db250YWluZXIvQ29udGFpbmVyLnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQUF1QztBQUNEO0FBRXRDLE1BQU1FLFVBQVVELGlFQUFhLENBQUM7O0VBRTVCLENBQUM7QUFDSCxTQUFTRyxVQUFVLEVBQUNDLFNBQVEsRUFBZ0IsRUFBRTtJQUMxQyxNQUFNQyxhQUFXTCw4REFBVSxDQUFDOztHQUU3QixDQUFDO0lBQ0YscUJBQ0UsOERBQUNLO2tCQUNHRDs7Ozs7O0FBR1I7QUFFQSxpRUFBZUQsU0FBU0EsRUFBQSIsInNvdXJjZXMiOlsid2VicGFjazovL25ldy1leHBlcnQvLi9zcmMvVGFncy9Db250YWluZXIvQ29udGFpbmVyLnRzeD9lZmEzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyBDaGlsZHJlbiB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgc3R5bGVkIGZyb20gXCJzdHlsZWQtY29tcG9uZW50c1wiXHJcbiBcclxuY29uc3QgQnV0dG9ucyA9IHN0eWxlZC5idXR0b25gXHJcbmZvbnQtZmFtaWx5OlwicG9wcGluc1wiXHJcbiAgYFxyXG5mdW5jdGlvbiBDb250YWluZXIoe2NoaWxkcmVufTp7Y2hpbGRyZW46YW55fSkge1xyXG4gICAgY29uc3QgV3JhcHBlcnRhZz1zdHlsZWQuZGl2YFxyXG4gICAgZm9udC1mYW1pbHk6J3BvcHBpbnMnO1xyXG4gICBgXHJcbiAgcmV0dXJuIChcclxuICAgIDxXcmFwcGVydGFnPlxyXG4gICAgICAge2NoaWxkcmVufVxyXG4gICAgPC9XcmFwcGVydGFnPlxyXG4gIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgQ29udGFpbmVyXHJcbiJdLCJuYW1lcyI6WyJSZWFjdCIsInN0eWxlZCIsIkJ1dHRvbnMiLCJidXR0b24iLCJDb250YWluZXIiLCJjaGlsZHJlbiIsIldyYXBwZXJ0YWciLCJkaXYiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/Tags/Container/Container.tsx\n");

/***/ }),

/***/ "./src/Tags/View/View.tsx":
/*!********************************!*\
  !*** ./src/Tags/View/View.tsx ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-components */ \"styled-components\");\n/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_1__);\n\n\nfunction View({ children  }) {\n    const View = (styled_components__WEBPACK_IMPORTED_MODULE_1___default().div)`\r\n    font-family:'poppins';\r\n    `;\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(View, {\n        children: children\n    }, void 0, false, {\n        fileName: \"D:\\\\Selt data\\\\Code\\\\Git Configured Code\\\\new-expert\\\\src\\\\Tags\\\\View\\\\View.tsx\",\n        lineNumber: 9,\n        columnNumber: 5\n    }, this);\n}\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (View);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvVGFncy9WaWV3L1ZpZXcudHN4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFzQztBQUd0QyxTQUFTQyxLQUFLLEVBQUNDLFNBQVEsRUFBZ0IsRUFBRTtJQUNyQyxNQUFNRCxPQUFNRCw4REFBVSxDQUFDOztJQUV2QixDQUFDO0lBQ0gscUJBQ0UsOERBQUNDO2tCQUNFQzs7Ozs7O0FBR1A7QUFFQSxpRUFBZUQsSUFBSUEsRUFBQSIsInNvdXJjZXMiOlsid2VicGFjazovL25ldy1leHBlcnQvLi9zcmMvVGFncy9WaWV3L1ZpZXcudHN4PzY0OWMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHN0eWxlZCBmcm9tIFwic3R5bGVkLWNvbXBvbmVudHNcIlxyXG4gXHJcbiBcclxuZnVuY3Rpb24gVmlldyh7Y2hpbGRyZW59OntjaGlsZHJlbjphbnl9KSB7XHJcbiAgICBjb25zdCBWaWV3PSBzdHlsZWQuZGl2YFxyXG4gICAgZm9udC1mYW1pbHk6J3BvcHBpbnMnO1xyXG4gICAgYFxyXG4gIHJldHVybiAoXHJcbiAgICA8Vmlldz5cclxuICAgICAge2NoaWxkcmVufVxyXG4gICAgPC9WaWV3PlxyXG4gIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgVmlld1xyXG4iXSwibmFtZXMiOlsic3R5bGVkIiwiVmlldyIsImNoaWxkcmVuIiwiZGl2Il0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./src/Tags/View/View.tsx\n");

/***/ }),

/***/ "./src/pages/index.tsx":
/*!*****************************!*\
  !*** ./src/pages/index.tsx ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Home)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/head */ \"next/head\");\n/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _Tags_Container_Container__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/Tags/Container/Container */ \"./src/Tags/Container/Container.tsx\");\n/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! styled-components */ \"styled-components\");\n/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var _Tags_View_View__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/Tags/View/View */ \"./src/Tags/View/View.tsx\");\n\n\n\n\n\n\nfunction Home() {\n    const Main = (styled_components__WEBPACK_IMPORTED_MODULE_3___default().main)``;\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {}, void 0, false, {\n                fileName: \"D:\\\\Selt data\\\\Code\\\\Git Configured Code\\\\new-expert\\\\src\\\\pages\\\\index.tsx\",\n                lineNumber: 16,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Main, {\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Tags_Container_Container__WEBPACK_IMPORTED_MODULE_2__[\"default\"], {\n                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Tags_View_View__WEBPACK_IMPORTED_MODULE_4__[\"default\"], {\n                        children: \"Home page\"\n                    }, void 0, false, {\n                        fileName: \"D:\\\\Selt data\\\\Code\\\\Git Configured Code\\\\new-expert\\\\src\\\\pages\\\\index.tsx\",\n                        lineNumber: 24,\n                        columnNumber: 11\n                    }, this)\n                }, void 0, false, {\n                    fileName: \"D:\\\\Selt data\\\\Code\\\\Git Configured Code\\\\new-expert\\\\src\\\\pages\\\\index.tsx\",\n                    lineNumber: 23,\n                    columnNumber: 9\n                }, this)\n            }, void 0, false, {\n                fileName: \"D:\\\\Selt data\\\\Code\\\\Git Configured Code\\\\new-expert\\\\src\\\\pages\\\\index.tsx\",\n                lineNumber: 22,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvcGFnZXMvaW5kZXgudHN4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7QUFTTUE7QUFUc0I7QUFHc0I7QUFDWjtBQUNIO0FBTXBCLFNBQVNLLE9BQU87SUFDN0IsTUFBTUMsT0FBS0gsK0RBQVcsQ0FBQyxDQUFDO0lBQ3hCLHFCQUNFOzswQkFDRSw4REFBQ0Ysa0RBQUlBOzs7OzswQkFNTCw4REFBQ0s7MEJBQ0MsNEVBQUNKLGlFQUFTQTs4QkFDUiw0RUFBQ0UsdURBQUlBO2tDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFLaEIsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL25ldy1leHBlcnQvLi9zcmMvcGFnZXMvaW5kZXgudHN4PzE5YTAiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IEhlYWQgZnJvbSAnbmV4dC9oZWFkJ1xuaW1wb3J0IEltYWdlIGZyb20gJ25leHQvaW1hZ2UnXG5pbXBvcnQgeyBJbnRlciB9IGZyb20gJ0BuZXh0L2ZvbnQvZ29vZ2xlJ1xuaW1wb3J0IENvbnRhaW5lciBmcm9tICdAL1RhZ3MvQ29udGFpbmVyL0NvbnRhaW5lcidcbmltcG9ydCBzdHlsZWQgZnJvbSBcInN0eWxlZC1jb21wb25lbnRzXCJcbmltcG9ydCBWaWV3IGZyb20gJ0AvVGFncy9WaWV3L1ZpZXcnXG5pbXBvcnQgQnV0dG9uIGZyb20gJ0AvVGFncy9CdXR0b24vQnV0dG9uJ1xuIFxuIFxuY29uc3QgaW50ZXIgPSBJbnRlcih7IHN1YnNldHM6IFsnbGF0aW4nXSB9KVxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBIb21lKCkge1xuICBjb25zdCBNYWluPXN0eWxlZC5tYWluYGBcbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPEhlYWQ+XG4gICAgICAgIHsvKiA8dGl0bGU+RXhwZXJ0IHx8IEFueSBTZXJ2aWNlIHwgQW55IFRpbWUgfCBBbnkgV2hlcmU8L3RpdGxlPlxuICAgICAgICA8bWV0YSBuYW1lPVwiZGVzY3JpcHRpb25cIiBjb250ZW50PVwiR2VuZXJhdGVkIGJ5IGNyZWF0ZSBuZXh0IGFwcFwiIC8+XG4gICAgICAgIDxtZXRhIG5hbWU9XCJ2aWV3cG9ydFwiIGNvbnRlbnQ9XCJ3aWR0aD1kZXZpY2Utd2lkdGgsIGluaXRpYWwtc2NhbGU9MVwiIC8+XG4gICAgICAgIDxsaW5rIHJlbD1cImljb25cIiBocmVmPVwiL2Zhdmljb24uaWNvXCIgLz4gKi99XG4gICAgICA8L0hlYWQ+XG4gICAgICA8TWFpbj5cbiAgICAgICAgPENvbnRhaW5lcj5cbiAgICAgICAgICA8Vmlldz5Ib21lIHBhZ2U8L1ZpZXc+IFxuICAgICAgICAgIDwvQ29udGFpbmVyPlxuICAgICAgIDwvTWFpbj5cbiAgICA8Lz5cbiAgKVxufSJdLCJuYW1lcyI6WyJpbnRlciIsIkhlYWQiLCJDb250YWluZXIiLCJzdHlsZWQiLCJWaWV3IiwiSG9tZSIsIk1haW4iLCJtYWluIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./src/pages/index.tsx\n");

/***/ }),

/***/ "next/head":
/*!****************************!*\
  !*** external "next/head" ***!
  \****************************/
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "styled-components":
/*!************************************!*\
  !*** external "styled-components" ***!
  \************************************/
/***/ ((module) => {

module.exports = require("styled-components");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./src/pages/index.tsx"));
module.exports = __webpack_exports__;

})();