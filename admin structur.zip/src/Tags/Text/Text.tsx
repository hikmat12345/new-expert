import React from 'react'
import styled from 'styled-components'

function Text() {
    const Text=styled.p``
    const Heasder=styled.h2``
  return (
    <Text>
      
    </Text>
  )
}

export default Text
