import { LoginContainer } from '@/styles/Container.styled';
import * as React from 'react'; 

 
function Signin() {
    
  return (
    <LoginContainer>
       Signin
    </LoginContainer>
  )
}

export default Signin
