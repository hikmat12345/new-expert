import { StyledHeader } from '@/styles/Header.styled'
import React from 'react'

export default function Header(props:any) {
  return (
    <StyledHeader>
      Header
    </StyledHeader>
  )
}
