
export const theme = {
    colors:{
        black: "#000",
        grayBlack:"grey", 
        white:"#fff",
        redColor:"red"
    }
}