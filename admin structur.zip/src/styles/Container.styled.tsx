import styled from 'styled-components'

export const Container = styled.div`
  width: 1226px;
  max-width: 100%;
  padding: 0 20px;
  padding: 0 8.5px 0 0;
  opacity: 0.5;
  margin: 0 auto;
`
export const LoginContainer = styled.div`
 padding: 20 70px;
 background-color: #f1f6fa;
`